#ifndef SO_LONG_H
#define SO_LONG_H

#include "mlx/mlx.h"
#include "mlx/mlx_int.h"

#endif