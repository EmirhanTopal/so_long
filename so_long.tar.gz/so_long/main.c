#include "so_long.h"


int main()
{
    void *mlx;
    void *mlx_new;

    mlx = mlx_init();
    mlx_new = mlx_new_window(mlx, 400, 400, "sa");
    if(mlx_new == NULL)
    {
        mlx_destroy_display(mlx);
        free(mlx);
        return(1);
    }
    mlx_loop(mlx);
}